lang = {}

lang.japanese		= 0
lang.english		= 1
lang.french			= 2
lang.spanish		= 3
lang.german			= 4
lang.italian		= 5
lang.dutch			= 6
lang.portuguese		= 7
lang.russian		= 8
lang.korean			= 9
lang.chinese_traditional	= 10
lang.chinese_simplified		= 11
lang.finnish		= 12
lang.swedish		= 13
lang.danish			= 14
lang.norwegian		= 15
lang.polish			= 16
lang.portuguese_brazil	= 17
lang.english_gb		= 18
lang.turkish		= 19
lang.spanish_la		= 20
lang.arabic			= 21
lang.french_canada	= 22

